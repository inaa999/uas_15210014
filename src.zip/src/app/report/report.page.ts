import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import Chart from 'chart.js/auto';

@Component({
  selector: 'app-report',
  templateUrl: './report.page.html',
  styleUrls: ['./report.page.scss'],
})
export class ReportPage implements OnInit {
  tanggal_keluar: any[] = [];
  kd_pengeluaran: any[] = [];

  constructor(
    private _apiService: ApiserviceService,
  ) { }

  ngOnInit() {
    this.fetchUangData();
  }

  async fetchUangData() {
    try {
      const res = await this._apiService.getuang();

      if (res.msg === 'ok') {
        // Mengambil data kd_pengeluaran dan tanggal_keluar dari res.data
        this.kd_pengeluaran = res.data.map((item: { kd_pengeluaran: any; }) => item.kd_pengeluaran);
        this.tanggal_keluar = res.data.map((item: { tanggal_keluar: any; }) => item.tanggal_keluar);

        // Memanggil metode untuk menampilkan grafik
        this.showChartData();
      } else if (res.msg === 'notFound') {
        console.log('Data not found');
      } else {
        console.error('Error fetching data:', res.err);
      }
    } catch (err) {
      console.error('Error fetching data:', err);
    }
  }

  showChartData() {
    const datasets = [{
      label: 'Kode Pengeluaran',
      data: this.kd_pengeluaran,
      borderWidth: 1,
      backgroundColor: [] // Array untuk menyimpan warna untuk setiap bar
    }];

    // Tentukan warna untuk setiap bar berdasarkan nilai kd_pengeluaran
    for (let i = 0; i < this.kd_pengeluaran.length; i++) {
      const value = this.kd_pengeluaran[i];

      // Pilih warna berdasarkan nilai
      const color = value > 20 ? 'green' : (value > 10 ? 'blue' : 'red');

      datasets[0].backgroundColor.push();
    }

    new Chart('myChart', {
      type: 'bar',
      data: {
        labels: this.tanggal_keluar,
        datasets: datasets
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }
}
