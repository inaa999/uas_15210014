import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-t-pemasukan',
  templateUrl: './t-pemasukan.page.html',
  styleUrls: ['./t-pemasukan.page.scss'],
})
export class TPemasukanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
