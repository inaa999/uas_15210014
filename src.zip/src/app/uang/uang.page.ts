import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uang',
  templateUrl: './uang.page.html',
  styleUrls: ['./uang.page.scss'],
})
export class UangPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
